namespace SGE.Aplicacion.Interfaces
{
    public interface IServicioHash
    {
        string GetHashSha256(string text);
    }
}
