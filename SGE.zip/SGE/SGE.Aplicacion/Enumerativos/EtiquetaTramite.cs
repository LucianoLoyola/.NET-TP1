﻿namespace SGE.Aplicacion;

public enum Etiqueta
{
    Escrito_presentado,
    Pase_a_estudio,

    Despacho,
    Resolución,
    Notificación,
    Pase_al_Archivo
}
