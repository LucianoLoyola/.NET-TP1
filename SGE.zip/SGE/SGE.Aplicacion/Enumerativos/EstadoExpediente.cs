﻿namespace SGE.Aplicacion;

public enum Estado
{
    Recien_iniciado,
    Para_resolver,
    Con_resolucion,
    En_notificacion,
    Finalizado
}
