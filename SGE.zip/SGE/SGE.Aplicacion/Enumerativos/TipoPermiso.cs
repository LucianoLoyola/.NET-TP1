public enum TipoPermiso
{
    Lectura,
    ExpedienteAlta,
    ExpedienteBaja,
    ExpedienteModificacion,
    TramiteAlta,
    TramiteBaja,
    TramiteModificacion
}